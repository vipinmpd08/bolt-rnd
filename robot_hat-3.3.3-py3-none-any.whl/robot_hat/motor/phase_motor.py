import logging
from threading import RLock
from typing import Optional, Union, cast

from robot_hat.data_types.config.motor import MotorDirection
from robot_hat.interfaces.motor_abc import MotorABC
from robot_hat.motor.mixins.motor_calibration import MotorCalibration
from robot_hat.utils import constrain

_log = logging.getLogger(__name__)


class PhaseMotor(MotorCalibration, MotorABC):
    """
    A concrete motor implementation for a Phase/Enable motor driver board.

    This implementation uses gpiozero's PhaseEnableMotor class to handle a motor
    that has separate phase (direction) and enable (speed control) inputs.
    """

    def __init__(
        self,
        phase_pin: Union[int, str],
        enable_pin: Union[int, str],
        pwm: bool = True,
        calibration_direction: MotorDirection = 1,
        calibration_speed_offset: float = 0,
        max_speed: int = 100,
        name: Optional[str] = None,
    ) -> None:
        """
        Initialize the motor with the specified GPIO pins.

        Args:
            phase_pin: GPIO pin for the phase/direction control signal.
            enable_pin: GPIO pin for the enable (PWM speed) control signal.
            pwm: Whether to use PWM output for speed control.
            calibration_direction: Calibration for the motor direction (+1 or -1).
            calibration_speed_offset: Adjustment for the motor speed calibration.
            max_speed: Maximum allowed speed (percentage value).
            name: Optional identifier for logging and debugging.
        """
        from gpiozero import PhaseEnableMotor

        super().__init__(
            calibration_direction=calibration_direction,
            calibration_speed_offset=calibration_speed_offset,
        )
        self._pwm = pwm
        self.max_speed = max_speed
        self.name = name or f"P{phase_pin}-E{enable_pin}"
        self._speed: float = 0
        self._applied_speed: float = 0
        self._lock = RLock()
        self._closed = False

        self._motor = PhaseEnableMotor(phase=phase_pin, enable=enable_pin, pwm=pwm)
        _log.debug(
            f"Initialized PhaseMotor {self.name} with phase_pin={phase_pin}, enable_pin={enable_pin}"
        )

    @property
    def speed(self) -> float:
        """
        Return the current motor speed (percentage).
        """
        return self._speed

    @property
    def applied_speed(self) -> float:
        """Return the calibrated command represented by the electrical output."""
        return self._applied_speed

    def _apply_speed_correction(self, speed: float) -> float:
        """
        Apply calibration and constrain the speed value.

        Args:
            speed: The desired speed percentage.

        Returns:
            Adjusted speed after applying limits.
        """
        return constrain(speed, -self.max_speed, self.max_speed)

    def set_speed(self, speed: float) -> None:
        """
        Set the motor's speed and direction. Accepts values from
        -max_speed to +max_speed and converts them to the 0.0 to 1.0 PWM scale.

        A positive speed will run the motor forward (phase off) while a negative
        speed will run it backward (phase on). If PWM is disabled the motor will
        run at full speed in the desired direction.

        Args:
            speed: Target speed percentage within [-max_speed, max_speed].
        """
        with self._lock:
            if self._closed:
                raise RuntimeError("Motor is closed")
            try:
                self._set_speed(speed)
            except Exception:
                try:
                    self.stop()
                except Exception:
                    _log.exception("Failed to stop phase motor after command failure")
                raise

    def _set_speed(self, speed: float) -> None:
        logical_speed, applied_speed = self.apply_calibration(speed, self.max_speed)
        if applied_speed > 0:
            if self._pwm:
                scale = applied_speed / self.max_speed
                _log.debug(
                    f"{self.name}: Running forward at {applied_speed}% "
                    f"(scale {scale:.2f})."
                )
                self._motor.forward(cast(int, scale))
            else:
                _log.debug(f"{self.name}: Running full forward (digital mode).")
                self._motor.forward(1)
        elif applied_speed < 0:
            if self._pwm:
                scale = abs(applied_speed) / self.max_speed
                _log.debug(
                    f"{self.name}: Running backward at {applied_speed}% "
                    f"(scale {scale:.2f})."
                )
                self._motor.backward(cast(int, scale))
            else:
                _log.debug(f"{self.name}: Running full backward (digital mode).")
                self._motor.backward(1)
        else:
            self.stop()

        self._speed = logical_speed
        self._applied_speed = applied_speed

    def stop(self) -> None:
        """
        Stop the motor.
        """
        with self._lock:
            if self._closed:
                return
            self._motor.stop()
            self._speed = 0
            self._applied_speed = 0
            _log.debug(f"{self.name}: Motor stopped.")

    def close(self) -> None:
        """
        Close the underlying GPIO resources.
        """
        with self._lock:
            if self._closed:
                return
            first_error: Exception | None = None
            for action in (self.stop, self._motor.close):
                try:
                    action()
                except Exception as error:
                    if first_error is None:
                        first_error = error
                    _log.exception("Failed to stop or close phase motor")
            self._closed = True
            if first_error is not None:
                raise first_error


def main() -> None:
    import argparse
    from time import sleep

    from robot_hat.utils import setup_env_vars

    logging.basicConfig(
        level=logging.DEBUG,
        format="%(asctime)s - %(levelname)s - %(message)s",
    )

    is_raspberry = setup_env_vars()
    default_enable_pin = 12 if is_raspberry else None

    parser = argparse.ArgumentParser(
        description="PhaseMotor test sequence using configurable GPIO pins."
    )
    parser.add_argument(
        "--phase-pin",
        type=int,
        default=5,
        help="GPIO pin for phase/direction control (default: 5)",
    )
    parser.add_argument(
        "--enable-pin",
        type=int,
        default=default_enable_pin,
        help="GPIO pin for enable (PWM) control (default: 12 on Raspberry Pi)",
    )
    parser.add_argument(
        "--pwm",
        action="store_true",
        help="Enable PWM mode for variable speed control.",
    )
    parser.add_argument(
        "--forward-speed1",
        type=float,
        default=50,
        help="Test speed (percentage) for initial forward run (default: 50)",
    )
    parser.add_argument(
        "--forward-speed2",
        type=float,
        default=100,
        help="Test speed (percentage) for maximum forward run (default: 100)",
    )
    parser.add_argument(
        "--backward-speed",
        type=float,
        default=-50,
        help="Test speed (percentage) for backward run (default: -50)",
    )
    parser.add_argument(
        "--forward-duration",
        type=float,
        default=3,
        help="Duration in seconds for forward runs (default: 3)",
    )
    parser.add_argument(
        "--backward-duration",
        type=float,
        default=3,
        help="Duration in seconds for backward runs (default: 3)",
    )
    parser.add_argument(
        "--pause",
        type=float,
        default=2,
        help="Pause duration in seconds between runs (default: 2)",
    )

    args = parser.parse_args()

    motor = PhaseMotor(
        phase_pin=args.phase_pin,
        enable_pin=args.enable_pin,
        pwm=args.pwm,
        name="phase_motor",
    )

    _log.info("PhaseMotor test sequence starting. Press CTRL+C to exit.")
    try:
        while True:
            _log.info(f"Running forward at {args.forward_speed1}% speed.")
            motor.set_speed(args.forward_speed1)
            sleep(args.forward_duration)

            _log.info(f"Running forward at {args.forward_speed2}% speed.")
            motor.set_speed(args.forward_speed2)
            sleep(args.forward_duration)

            _log.info("Stopping motor.")
            motor.stop()
            sleep(args.pause)

            _log.info(f"Running backward at {abs(args.backward_speed)}% speed.")
            motor.set_speed(args.backward_speed)
            sleep(args.backward_duration)

            _log.info("Stopping motor.")
            motor.stop()
            sleep(args.pause)

    except KeyboardInterrupt:
        _log.info("Exiting and cleaning up resources...")

    finally:
        motor.stop()
        sleep(0.5)
        motor.close()


if __name__ == "__main__":
    main()
